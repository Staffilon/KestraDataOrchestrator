# TODO 

* Implementazione RPC WAMP
* Autenticazione per l’IoT (es. OAuth 2.0)
* Reazione/Azione: non solo generare dati in uscita (publish) ma anche “reagire” (subscribe) ad eventi, generando eventuali output di risposta
* Servizi avanzati si registry/discovery delle entità simulate



