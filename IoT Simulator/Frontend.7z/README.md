# JsonDataGenerator 
![N|Solid](https://camo.githubusercontent.com/fd5718136c433ef04e3b2e9f7a66ae27dc023191/68747470733a2f2f666f7274686562616467652e636f6d2f696d616765732f6261646765732f6d6164652d776974682d6a6176617363726970742e737667) ![N|Solid](https://camo.githubusercontent.com/d24f2f8414437a9491ea3145cafd373167315d50/68747470733a2f2f666f7274686562616467652e636f6d2f696d616765732f6261646765732f6275696c742d776974682d6c6f76652e737667) ![N|Solid](https://camo.githubusercontent.com/9de09295bb0ddc631e7180c44110bcbe31f7f179/68747470733a2f2f666f7274686562616467652e636f6d2f696d616765732f6261646765732f666f722d796f752e737667) 

Json Data Generator è un simulatore realizzato da ACES, Inc, azienda informatica statunitense, scritto in java e poi reso open source. Il simulatore è nato dalla necessità di avere un generatore di json offline.
L’obiettivo principale del simulatore è quello di generare flussi continui di dati in formato json, che possono essere utilizzati da un’applicazione per testarne il funzionamento. Con una semplice configurazione, con cui l’utente definisce che tipo di dati devono essere generati, con quale frequenza e dove inviarli, il simulatore è in grado di produrre tali stream. 
Per il backend è stato ripreso il [Json Data Generator](https://github.com/everwatchsolutions/json-data-generator) già realizzato dalla stessa azienda.
Per semplificare l'utilizzo del simulatore è stata realizzata un'interfaccia grafica che permette all'utente di creare ed eseguire simulazioni in maniera veloce ed efficace. 

### USAGE

Per utilizzare il simulatore tramite interfaccia grafica basterà lanciare i seguenti comandi.

```bash
 git clone https://massimocallisto/stage-ui-simulatore-iot.git
 cd Frontend/json-data-generator-frontend
 npm install
 npm start
```
L'applicazione sarà poi raggiungibile all'indirizzo http://localhost:3000, utilizzato da React come percorso di default.
