import { WORKFLOW_CONFIG } from "../constants/action-types";

export const addWorkflowConfig = (data) => ({
    type: WORKFLOW_CONFIG,
    payload: data
})