import {SIMULATION} from "../constants/action-types";

export const addSimulation = data => ({
    type: SIMULATION,
    payload: data
}
)