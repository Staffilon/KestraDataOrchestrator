import {WORKFLOW_NAME} from "../constants/action-types";

export const addWorkflowName = (data) => ({
    type: WORKFLOW_NAME,
    payload: data
}
)