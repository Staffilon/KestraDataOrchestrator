import { ISRUNNING } from "../constants/action-types";

export const setRunning = () => ({
    type: ISRUNNING
    
}
)