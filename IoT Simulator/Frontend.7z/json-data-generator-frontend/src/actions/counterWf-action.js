import { COUNTER_WF } from "../constants/action-types";

export const addCounterWf = data => ({
    type: COUNTER_WF,
    payload: data
}
)