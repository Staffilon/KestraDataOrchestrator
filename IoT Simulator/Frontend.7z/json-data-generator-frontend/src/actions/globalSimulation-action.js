import { GLOBAL_SIMULATION } from "../constants/action-types";

export const addGlobalSimulation = data => ({
    type: GLOBAL_SIMULATION,
    payload: data
}
)