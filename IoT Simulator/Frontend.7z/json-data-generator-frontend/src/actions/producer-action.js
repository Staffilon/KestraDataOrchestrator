import {TYPE_PRODUCER} from "../constants/action-types";

export const addProducer = data => ({
    type: TYPE_PRODUCER,
    payload: data
}
)