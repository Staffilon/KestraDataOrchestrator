import { N_STEP } from "../constants/action-types";

export const addnStep = data => ({
    type: N_STEP,
    payload: data
}
)