import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Display from './components/Display';


function App() {
  return (
    <div className="App">
      <Display/>
    </div>

  );
}

export default App;
