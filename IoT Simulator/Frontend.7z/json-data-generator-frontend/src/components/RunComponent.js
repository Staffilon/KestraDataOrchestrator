import React from 'react'
import '../App.css';
import axios from 'axios';
import { Button, FormControl, InputLabel, MenuItem, Snackbar, Select } from '@material-ui/core';
import { BsFillCaretRightFill } from 'react-icons/bs';
import { useDispatch, useSelector } from 'react-redux'
import MuiAlert from '@material-ui/lab/Alert';
import { setRunning } from '../actions/isRunning-action';
import SockJsClient from 'react-stomp';
import { AiFillWarning } from 'react-icons/ai';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const RunComponent = () => {
    const statoSimulation = useSelector(state => state.globalSimu.data)
    const dispatch = useDispatch();
    const [open, setOpen] = React.useState(false);
    const [isRunning, setIsRunning] = React.useState(false);

    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }
    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpen(false);
    };

    const run = () => {
        axios.post('http://localhost:8080/run', {
            "name": sim + ".json"
        }).catch((error) => {
            console.log(error)
            setOpen(true);
        })
        dispatch(setRunning())
        setIsRunning(true);
        sendMessage()

    }
    const [sim, setSim] = React.useState('');
    const [roba, setRoba] = React.useState([]);
    const handleChange = (event) => {
        setSim(event.target.value)
    };

    const [clientRef, setClientRef] = React.useState();

    function sendMessage() {
        clientRef.sendMessage('/app/output', " ");
    }

    const message = (e) => {
        let data = [...roba]
        data.unshift(e)
        setRoba(data);
    }


    return statoSimulation.length === 0 ? (<div className="TextAlert"><AiFillWarning color="red" size="7vh"></AiFillWarning>&nbsp; Non ci sono simulazioni da eseguire</div>) :
        (<div>
            <div className="OpenDisplay" >
                <Card style={{ width: 500 }}>
                    <CardContent>
                        <h4>Seleziona la simulazione da Eseguire</h4>
                        <FormControl style={{ width: 300 }} variant='outlined' required>
                            <InputLabel>Simulation</InputLabel>
                            <Select name='simulation'
                                label='Simulation' defaultValue=''
                                value={sim}
                                onChange={handleChange} >
                                {statoSimulation.map((sim, index) =>
                                    <MenuItem key={index} value={sim.simName}>{sim.simName}</MenuItem>
                                )}
                            </Select>
                        </FormControl>
                        <br></br><br></br>
                        <SockJsClient url='http://localhost:8080/output' topics={['/topic/output']}
                            onConnect={() => { console.log("connected"); }}
                            onDisconnect={() => { console.log("Disconnected"); }}
                            onMessage={message}
                            ref={(client) => { setClientRef(client) }} />


                        <Button variant="contained" color="primary" component="span" startIcon={<BsFillCaretRightFill />} size="large"
                            disabled={sim === "" || isRunning} onClick={run}  >
                            Run
            </Button>

                        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                            <Alert onClose={handleClose} severity="warning">
                                La simulazione NON è stata configurata correttamente
                </Alert>
                        </Snackbar>
                    </CardContent>
                </Card>
            </div>
            {isRunning ?
                <div className="card">
                    <Card style={{ width: 800, height: 500, overflowY: "scroll" }}>
                        <CardContent>
                            <h3> <center>Output</center></h3> Running...

                 {roba.map((messaggio, index) => <div key={index}>{messaggio}</div>)}
                        </CardContent>
                    </Card>
                </div> : <div> </div>}
        </div>
        )

}
export default RunComponent;