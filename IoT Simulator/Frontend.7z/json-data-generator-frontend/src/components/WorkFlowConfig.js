import React from 'react'
import '../App.css';
import Switch from '@material-ui/core/Switch';
import { useHistory } from 'react-router-dom';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import TextField from '@material-ui/core/TextField';
import { useSelector, useDispatch } from 'react-redux';
import { addWorkflowConfig } from '../actions/WorkflowConfig-action';
import { addnStep } from '../actions/nStep-action';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const WorkFlowConfig = () => {
    const formRef = React.useRef();
    const history = useHistory();
    const wf = useSelector(state => state.workflow.data);
    const nStep = useSelector(state => state.nStep.data)
    const dispatch = useDispatch();

    const handleSubmit = e => {
        if (formRef.current.reportValidity()) {
            e.preventDefault();
            history.push("/steps")
        }
    };

    const handleChange = (event) => {
        let data = { ...wf, [event.target.name]: event.target.checked }
        if (event.target.name === 'repeatWorkflow')
            data.iterations = -1;
        dispatch(addWorkflowConfig(data));
    };

    const handleChange2 = (event) => {
        let data = { ...wf, [event.target.name]: event.target.value }
        dispatch(addWorkflowConfig(data));
    };

    const handleChange3 = (event) => {
        dispatch(addnStep(event.target.value));
    };

    const handleChange4 = (event) => {
        let data = { ...wf, [event.target.name]: parseInt(event.target.value, 10) }
        dispatch(addWorkflowConfig(data));
    };

    return (
        <form className="SimForm" ref={formRef} onSubmit={handleSubmit}>
            <Card style={{ padding: 40, width: 700 }}>
                <CardContent>
                    <h2>Workflow Configuration</h2>
                    <div className='Campo'>
                        <TextField id="standard-number" label="Event Frequency (ms)" type="number"
                            InputProps={{ inputProps: { min: 0, step: 50 } }}
                            variant='outlined'
                            value={wf.eventFrequency} onChange={handleChange4} name='eventFrequency' required />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <FormControlLabel
                            value="start"
                            control={<Switch checked={wf.varyEventFrequency} onChange={handleChange} name="varyEventFrequency" />}
                            label="Vary event frequency"
                            labelPlacement="start"
                        />
                    </div>
                    <div className='Campo'>
                        <FormControlLabel
                            value="start"
                            control={<Switch checked={wf.repeatWorkflow} onChange={handleChange} name="repeatWorkflow" />}
                            label="Repeat workflow"
                            labelPlacement="start"
                        /> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            {wf.repeatWorkflow ?

                            <TextField style={{ alignContent: "left" }} id="standard-number" label="Iterarions" type="number"
                                InputProps={{ inputProps: { min: -1 } }}
                                variant='outlined'
                                value={wf.iterations} onChange={handleChange4} name='iterations' required />
                            :

                            <TextField id="standard-number" label="Iterarions" type="number"
                                InputProps={{ inputProps: { min: -1 } }}
                                variant='outlined'
                                value={wf.iterations} name='iterations' disabled />
                        }
                    </div>
                    <div className='Campo'>
                        <TextField id="standard-number" label="Time Between Repeat (ms)" type="number"
                            InputProps={{ inputProps: { min: 0, step: 50 } }} variant='outlined'
                            value={wf.timeBetweenRepeat} onChange={handleChange4} name='timeBetweenRepeat' required />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <FormControlLabel
                            value="start"
                            control={<Switch checked={wf.varyRepeatFrequency} onChange={handleChange} name="varyRepeatFrequency" />}
                            label="Vary repeat frequency"
                            labelPlacement="start"
                        />
                    </div>
                    <div className='Campo'>
                        <FormControl style={{ width: 300 }} variant='outlined'>
                            <InputLabel>Step run mode</InputLabel>
                            <Select
                                name="stepRunMode"
                                value={wf.stepRunMode}
                                onChange={handleChange2}
                                label="Step run mode">
                                <MenuItem value='sequencial'>Sequencial</MenuItem>
                                <MenuItem value='random'>Random</MenuItem>
                                <MenuItem value='pick-one'>Pick-one</MenuItem>
                            </Select>
                        </FormControl>
                    </div>
                    <div className='Campo'>
                        <TextField id="standard-number" label="Number of steps" type="number" style={{ width: 300 }}
                            InputProps={{ inputProps: { min: 1 } }} variant='outlined'
                            value={nStep} onChange={handleChange3} name='nSteps' />
                    </div>
                    <div className="submit-button">
                        <button className="btn btn-primary mr-2" onSubmit={handleSubmit} > Next </button>
                    </div>
                </CardContent>
            </Card>
        </form>
    )
}
export default WorkFlowConfig;