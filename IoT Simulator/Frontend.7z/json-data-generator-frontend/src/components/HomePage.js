 import React from 'react'
 import '../App.css';

 const HomePage = () => {

     return (
         <div>

         </div>
     )
 }
export default HomePage;
