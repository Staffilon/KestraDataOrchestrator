import React, { useEffect, useRef } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import { useDispatch, useSelector } from 'react-redux';
import { JsonEditor as Editor } from 'jsoneditor-react';
import 'jsoneditor-react/es/editor.min.css';
import '../App.css';
import { addWorkflowConfig } from '../actions/WorkflowConfig-action';
import axios from 'axios';
import { addSimulation } from '../actions/Simulation-action';
import { addnStep } from '../actions/nStep-action';
import { addCounterWf } from '../actions/counterWf-action';
import { addGlobalSimulation } from '../actions/globalSimulation-action'
import { useHistory } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    button: {
        marginRight: theme.spacing(1),
    },
    instructions: {
        marginTop: theme.spacing(1),
        marginBottom: theme.spacing(1),
    },
}));

const Step2 = () => {

    const nStep = useSelector(state => state.nStep.data)
    const counterWf = useSelector(state => state.counterWf)
    const wf = useSelector(state => state.workflow.data);
    const statoSimulation = useSelector(state => state.simulation.data)
    const globalSimu = useSelector(state => state.globalSimu.data)
    const history = useHistory();
    const dispatch = useDispatch();

    const [activeStep, setActiveStep] = React.useState(0);
    let init = {
        duration: 0,
        iterations: -1,
        producerConfig: {},
        config: [{}]
    }

    const [state, setState] = React.useState(init)
    const classes = useStyles();
    const jsonEditorRef = useRef(null)
    function getSteps() {
        let data = [];
        for (let i = 0; i < nStep; i++) {
            data.push('STEP ' + (i + 1))
        }
        return data;
    }

    const handleChange = (event) => {
        setState(event);
    };

    const saveStep = () => {
        const values = wf;
        values.steps[activeStep] = state;
        dispatch(addWorkflowConfig(values));
    }

    const handleNext = () => {
        saveStep()
        if (wf.steps.length > activeStep + 1) {
            setState(wf.steps[activeStep + 1])
        }
        else {
            setState(init)
        }
        setActiveStep(activeStep + 1)
    };

    const handleBack = () => {
        saveStep();
        setState(wf.steps[activeStep - 1])
        setActiveStep((activeStep) => activeStep - 1);
    };

    const saveSimu = () => {
        const values = [...globalSimu];
        values.push(statoSimulation)
        dispatch(addGlobalSimulation(values))
        dispatch(addSimulation({
            simName: '',
            roba: {
                producers: [{}],
                workflows: [{}]
            },
            w: []
        }))
    }
    const nextWF = () => {
        if (counterWf < statoSimulation.roba.workflows.length - 1) {
            dispatch(addCounterWf(counterWf + 1))
            history.push("/wfConfig")
        }
        else {
            saveSimu();
            dispatch(addCounterWf(0))
            history.push("/home")
        }
        dispatch(addWorkflowConfig({
            eventFrequency: 0,
            varyEventFrequency: true,
            repeatWorkflow: false,
            iterations: -1,
            timeBetweenRepeat: 0,
            varyRepeatFrequency: false,
            stepRunMode: 'sequencial',
            steps: []
        }))
    }
    const handleFinish = () => {
        saveStep();
        let values = { ...statoSimulation };
        values.w.push(wf);
        dispatch(addSimulation(values));
        let stato = JSON.stringify(statoSimulation.w[counterWf], undefined, 5);
        axios.post('http://localhost:8080/create', {
            "name": statoSimulation.roba.workflows[counterWf].workflowFilename,
            "data": stato
        });
        dispatch(addnStep(1));
        nextWF();
    }

    const handleReset = () => {
        setActiveStep(0);
        let data = wf;
        data.steps = []
        dispatch(addWorkflowConfig(data))
        setState(init);
    };

    const isActive = () => {
        if (wf.steps.length >= activeStep) {
            return wf.steps[activeStep]
        }
        else return init;
    }
    useEffect(() => {
        if (jsonEditorRef.current !== null) {
            jsonEditorRef.current.set(state)
        }
    }, [activeStep])

    const setRef = instance => {
        if (instance) {
            jsonEditorRef.current = instance.jsonEditor;
        } else {
            jsonEditorRef.current = null;
        }
    };

    return (
        <div className='Step'>
            <h2>Step Config</h2>
            <div className={classes.root}>
                <Stepper activeStep={activeStep}>
                    {getSteps().map((label, index) => {
                        const stepProps = {};
                        const labelProps = {};
                        return (
                            <Step key={label} {...stepProps}>
                                <StepLabel {...labelProps}>{label}</StepLabel>
                            </Step>
                        );
                    })}
                </Stepper>
                <div className='Editor'>
                    <Editor ref={setRef} value={isActive} onChange={handleChange} />
                </div>
            </div>
            <div style={{ marginTop: 20 }}> <center>
                <Button onClick={handleReset} className={classes.button} variant="contained" color="secondary">
                    Reset
                    </Button>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button disabled={activeStep === 0} onClick={handleBack} className={classes.button}>
                    Back
                </Button>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                {activeStep === getSteps().length - 1 ?
                    <Button variant="contained" color="primary"
                        onClick={handleFinish} className={classes.button} >Create</Button> :
                    <Button variant="contained" color="primary"
                        onClick={handleNext} className={classes.button} >Next</Button>}
            </center>
            </div>
        </div>
    );
}

export default Step2;