import React from 'react'
import '../App.css';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import { Button } from '@material-ui/core';
import { AiOutlineCloudUpload } from 'react-icons/ai';
import { useDispatch, useSelector } from 'react-redux';
import { addGlobalSimulation } from '../actions/globalSimulation-action';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const OpenFile = () => {

    const history = useHistory();
    const [sim, setSim] = React.useState('');
    const [wf, setWf] = React.useState([]);
    const dispatch = useDispatch();
    const [contentSim, setContentSim] = React.useState('')
    const [contentWf, setContentWf] = React.useState([])
    const globalSim = useSelector(state => state.globalSimu.data)

    let fileReader;
    const createSim = () => {
        let stato = JSON.stringify(contentSim, undefined, 5);
        axios.post('http://localhost:8080/create', {
            "name": sim,
            "data": stato
        });
    }

    const createWf = () => {
        for (let i = 0; i < contentWf.length; i++) {
            let stato = JSON.stringify(contentWf[i], undefined, 5);
            axios.post('http://localhost:8080/create', {
                "name": wf[i],
                "data": stato
            });
        }
    }

    const create = () => {
        createSim()
        createWf()
        let data = { simName: sim.slice(0, sim.length - 5), roba: contentSim, w: contentWf }
        const values = [...globalSim];
        values.push(data)
        dispatch(addGlobalSimulation(values))
        history.push('/home');
    }

    const hanldeFileReadSim = () => {
        setContentSim(JSON.parse(fileReader.result));
    }
    const chooseSim = (event) => {
        setSim(event.target.files[0].name)
        fileReader = new FileReader();
        fileReader.onloadend = hanldeFileReadSim;
        fileReader.readAsText(event.target.files[0]);
    }

    const readmultifiles = (e) => {
        const files = e.currentTarget.files;
        let data = [];
        let values = [];
        Object.keys(files).forEach(i => {
            const file = files[i];
            values.push(file.name);
            setWf(values)
            const reader = new FileReader();
            reader.onload = (e) => {
                data.push(JSON.parse(reader.result))
                setContentWf(data)
            }
            reader.readAsBinaryString(file);
        })
    };

    return (
        <div className="OpenDisplay">
            <Card style={{ width: 450 }}>
                <CardContent>
                    <h3>Seleziona Simulazione</h3>
                    <input type="file" id="file" accept=".json" onChange={chooseSim} />
                    <br></br><br></br>
                    <h3>Seleziona i workflows</h3>
                    <input type="file" id="file2" accept=".json" onChange={readmultifiles} multiple='multiple' />
                    <br></br><br></br>
                    {JSON.stringify(wf) === JSON.stringify([]) || sim === "" ? <Button variant="contained" disabled color="primary" component="span" startIcon={<AiOutlineCloudUpload />} size="large" onClick={create}  >
                        Upload</Button> : <Button variant="contained" color="primary" component="span" startIcon={<AiOutlineCloudUpload />} size="large" onClick={create}  >
                            Upload</Button>}
                </CardContent>
            </Card>
        </div>
    )
}
export default OpenFile;