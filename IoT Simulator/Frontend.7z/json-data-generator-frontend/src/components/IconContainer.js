import React from 'react'
import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { VscNewFile } from 'react-icons/vsc';
import { AiFillFolderOpen } from 'react-icons/ai';
import { BiExport, BiHelpCircle } from 'react-icons/bi';
import { BsFillCaretRightFill, BsStopFill } from 'react-icons/bs';
import { Link } from 'react-router-dom';
import { useHistory } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux';
import { addSimulation } from '../actions/Simulation-action';
import axios from 'axios';
import { setRunning } from '../actions/isRunning-action';

const IconContainer = () => {

    const statorun = useSelector(state => state.running)
    const dispatch = useDispatch();

    const history = useHistory();
    const handleClick = e => {
        e.preventDefault();
        let data = {
            simName: '',
            roba: {
                workflows: [{}],
                producers: [{}],
            },
            w: []
        };
        dispatch(addSimulation(data));
        history.push("/new");
    };

    const handleClickRun = () => {
        history.push("/run")
    }
    const handleClickPause = () => {
        axios.post('http://localhost:8080/stop');
        history.push("/home");
        dispatch(setRunning())
    }

    return (
        <div className="Navbar">
            <a href="https://www.filippetti.it/" className="Image">
                <img src="https://bebeez.it/files/2017/01/filippetti.png" width='100%' alt='Filippetti'></img>
            </a>

            <button className="BottoneMenu" onClick={handleClick} >
                <VscNewFile size="10vh" />New
            </button>
            <Link to='/open' className="BottoneMenu">
                <AiFillFolderOpen size='10vh' /> Open
            </Link>
            <Link to='/export' className="BottoneMenu" >
                <BiExport size="10vh" /> Export
            </Link>
            {statorun === true ? (<button disabled className="BottoneDis" onClick={handleClickRun} >
                <BsFillCaretRightFill size="10vh" color="grey" /> Run </button>)
                : (<button className="BottoneMenu" onClick={handleClickRun} >
                    < BsFillCaretRightFill size="10vh" /> Run
                </button>)}
            { statorun === false ? (<button disabled className="BottoneDis" onClick={handleClickPause} >
                <BsStopFill size="10vh" color="grey" /> Stop
            </button>)
                : (<button className="BottoneMenu" onClick={handleClickPause} >
                    <BsStopFill size="10vh" /> Stop
                </button>)}
            <Link to='/help' className="BottoneMenu" >
                <BiHelpCircle size="10vh" /> Help
            </Link>
        </div>
    )
}

export default IconContainer;