import React from 'react'
import '../App.css';
import { BrowserRouter, Switch, Route } from 'react-router-dom'
import IconContainer from './IconContainer'
import NewSimulationForm from './NewSimulationForm';
import WorkFlowConfig from './WorkFlowConfig';

import HomePage from './HomePage'
import LeftBar from './LeftBar'

import RunComponent from './RunComponent';
import OpenFile from './OpenFile';
import Step2 from './Step';
import ModifyWorkflow from './ModifyWorkflow';
import ModifyProducer from './ModifyProducer'
import Helper from './Helper';
import ExportComponent from './ExportComponent';

const Display = () => {
  return (
    <BrowserRouter>
      <IconContainer />
      <div className="Display">
        <LeftBar />
        <Switch>
          <Route path="/home" component={HomePage} />
          <Route path="/new" component={NewSimulationForm} />
          <Route path="/wfConfig" component={WorkFlowConfig} />
          <Route path="/steps" component={Step2} />
          <Route path="/run" component={RunComponent} />
          <Route path="/open" component={OpenFile} />
          <Route path="/export" component={ExportComponent} />
          <Route path="/help" component={Helper} />
          <Route path="/modifyWorkflow/:indiceSimu/:index" component={ModifyWorkflow} />
          <Route path="/modifyProducer/:indiceSimu/:index" component={ModifyProducer} />
        </Switch>
      </div>
    </BrowserRouter>

  )
}
export default Display;
