import React, { useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { JsonEditor } from "jsoneditor-react/es";
import { addSimulation } from "../actions/Simulation-action";
import axios from 'axios';
import { Button } from "@material-ui/core";

const ModifyWorkflow = () => {
    let { indiceSimu, index } = useParams();
    const globalSimulation = useSelector(state => state.globalSimu.data)
    const dispatch = useDispatch();
    const history = useHistory();
    const jsonEditorRef = React.useRef(null)
    let data = globalSimulation[indiceSimu].w[index];
    const handleChange = (event) => {
        data = event;
    }

    const save = () => {
        let sim = [...globalSimulation];
        sim[indiceSimu].w[index] = data;
        dispatch(addSimulation(sim));

        let stato = JSON.stringify(data, undefined, 5);;
        axios.post('http://localhost:8080/create', {
            "name": globalSimulation[indiceSimu].roba.workflows[index].workflowFilename,
            "data": stato
        });
        history.push("/home");
    }
    useEffect(() => {
        if (jsonEditorRef.current !== null) {
            jsonEditorRef.current.set(data)
        }
    }, [data])

    const setRef = instance => {
        if (instance) {
            jsonEditorRef.current = instance.jsonEditor;
        } else {
            jsonEditorRef.current = null;
        }
    };
    return (
        <div className="OpenDisplayEditor">
            <div >
                <JsonEditor ref={setRef} value={data} onChange={handleChange} />
            </div>
            <div style={{ paddingTop: 10 }}>
                <Button variant="contained" color="primary" component="span" size="large" onClick={save}>Save</Button>
            </div>
        </div>
    )
}
export default ModifyWorkflow