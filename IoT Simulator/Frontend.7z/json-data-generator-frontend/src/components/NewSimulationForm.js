import React from 'react'
import '../App.css';
import DynamicFields from './DynamicFields';
import DynamicSelect from './DynamicSelect';
import { Snackbar, TextField } from '@material-ui/core';
import axios from 'axios';
import { useHistory } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux';
import { addSimulation } from '../actions/Simulation-action';
import { addWorkflowName } from '../actions/workflowName-action';
import { addProducer } from '../actions/producer-action';
import MuiAlert from '@material-ui/lab/Alert';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const NewSimulationForm = () => {

  const statoProducer = useSelector(state => state.producer.data)
  const statoWorkflow = useSelector(state => state.wfname.data)
  const statoSimulation = useSelector(state => state.simulation.data)
  const dispatch = useDispatch();
  const history = useHistory();

  const [open, setOpen] = React.useState(false);

  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  const getProducers = () => {
    let valori = [];
    statoProducer.map((producer) => {
      valori = [...valori, producer.s];
    })
    return valori;
  }

  const newSim = () => {
    let data = { ...statoSimulation }
    data.roba.workflows = statoWorkflow;
    data.roba.producers = getProducers();
    dispatch(addSimulation(data));
  };

  const control = () => {
    let ripetuto = false;
    statoWorkflow.map((wf, indice1) => {
      if (statoSimulation.simName === wf.workflowName)
        ripetuto = true
      statoWorkflow.map((wf2, indice2) => {
        if (wf.workflowName === wf2.workflowName && indice1 !== indice2)
          ripetuto = true
      })
    })
    return ripetuto
  }

  const handleSubmit = e => {
    if (formRef.current.reportValidity()) {
      if (control()) {
        e.preventDefault();
        setOpen(true)
      }
      else {
        e.preventDefault();
        newSim();
        let stato = JSON.stringify(statoSimulation.roba, undefined, 5);
        axios.post('http://localhost:8080/create', {
          "name": statoSimulation.simName + '.json',
          "data": stato
        });
        dispatch(addWorkflowName([{ workflowName: '', workflowFilename: '' }]))
        dispatch(addProducer([{ type: '', s: {} }]))
        history.push("/wfConfig");
      }
    }

  };

  const handleChange2 = (event) => {
    let data = { ...statoSimulation }
    data.simName = event.target.value;
    dispatch(addSimulation(data));
  };

  const formRef = React.useRef();

  return (
    <form className="SimForm" ref={formRef} >
      <Card style={{padding:40, width:700}}>
        <CardContent>
      <h2>Simulation Configuration</h2>
      <div className='Field'>
        <TextField className='Input' label="Name simulation" variant="outlined"
          value={statoSimulation.simName} onChange={handleChange2} required />
      </div>
      <br />
      <DynamicFields />
      <br />
      <DynamicSelect c />
      <br />
      <div className="submit-button">
        <button className="btn btn-primary mr-2" onClick={handleSubmit} > Next </button>
      </div>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="warning">
          La simulazione e i workflow non possono avere nomi uguali
          </Alert>
      </Snackbar>
      </CardContent>
      </Card>
    </form>
  )
}
export default NewSimulationForm;