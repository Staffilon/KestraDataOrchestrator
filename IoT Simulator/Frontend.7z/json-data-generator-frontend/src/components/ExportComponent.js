import React from 'react'
import '../App.css';
import axios from 'axios';
import { Button, FormControl, InputLabel, MenuItem, Snackbar, Select } from '@material-ui/core';
import { useSelector } from 'react-redux'
import MuiAlert from '@material-ui/lab/Alert';
import { BiExport } from 'react-icons/bi';
import { AiFillWarning } from 'react-icons/ai';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const ExportComponent = () => {

    const statoSimulation = useSelector(state => state.globalSimu.data)
    const [sim, setSim] = React.useState('');
    const [open, setOpen] = React.useState(false);

    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }
    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const exportWf = () => {
        statoSimulation.map(simulation => {
            if (simulation.simName === sim) {
                simulation.roba.workflows.map(wf =>
                    axios.get(`http://localhost:8080/read/${wf.workflowFilename}`, {
                        responseType: 'arraybuffer',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        }
                    })
                        .then(response => {
                            const url = window.URL.createObjectURL(new Blob([response.data]));
                            const link = document.createElement('a');
                            link.href = url;
                            link.setAttribute('download', wf.workflowFilename);
                            document.body.appendChild(link);
                            link.click();
                        }).catch(error => console.log("errore")))
            }
        }
        )
    }

    const exportSim = () => {
        axios.get(`http://localhost:8080/read/${sim}.json`, {
            responseType: 'arraybuffer',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        })
            .then(response => {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', sim + '.json');
                document.body.appendChild(link);
                link.click();
            }).catch(error => console.log("errore"));
        exportWf()
    }


    const handleChange = (event) => {
        setSim(event.target.value)
    };

    return statoSimulation.length === 0 ? (<div className="TextAlert"><AiFillWarning color="red" size="7vh"></AiFillWarning> &nbsp; Non ci sono simulazioni da salvare</div>) :
        (<div className="OpenDisplay">
            <Card style={{ width: 500 }}>
                <CardContent>
                    <h4>Seleziona la simulazione da Salvare</h4>
                    <FormControl style={{ width: 300 }} variant='outlined' required>
                        <InputLabel>Simulation</InputLabel>
                        <Select name='simulation'
                            label='Simulation' defaultValue=''
                            value={sim}
                            onChange={handleChange} >
                            {statoSimulation.map((sim, index) =>
                                <MenuItem key={index} value={sim.simName}>{sim.simName}</MenuItem>
                            )}
                        </Select>
                    </FormControl>
                    <br></br><br></br>
                    <Button variant="contained" color="primary" component="span" startIcon={<BiExport />}
                        size="large" onClick={exportSim} disabled={sim === ''}>
                        Export
                </Button>
                    <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                        <Alert onClose={handleClose} severity="warning">
                            La simulazione NON è stata configurata correttamente
                </Alert>
                    </Snackbar>
                </CardContent>
            </Card >

        </div>)
}
export default ExportComponent;