import React from "react";
import '../App.css';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import { BiMinusCircle, BiPlusCircle } from 'react-icons/bi';
import IconButton from '@material-ui/core/IconButton'
import MqttConfig from "../producers/MqttConfig";
import KafkaConfig from "../producers/KafkaConfig";
import AzureConfig from "../producers/AzureIotHubConfig";
import TranquilityConfig from "../producers/TranquilityConfig";
import NatsConfig from "../producers/NatsConfig";
import KinesisConfig from "../producers/KinesisConfig";
import HttpPostConfig from "../producers/Http-postConfig";
import FileConfig from "../producers/FileConfig";
import { useDispatch, useSelector } from "react-redux";
import { addProducer } from '../actions/producer-action';
import LoggerConfig from "../producers/LoggerProducerConfig";
import { Snackbar } from "@material-ui/core";
import MuiAlert from '@material-ui/lab/Alert';
import WampConfig from "../producers/WampConfig";

const DynamicSelect = () => {

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const handleInputChange = (index, event) => {
        const values = [...stato];
        values[index].type = event.target.value;
        values[index].s = {}
        dispatch(addProducer(values));
    };

    const [nProd, setNProd] = React.useState(1);

    const selectType = (index) => {
        switch (stato[index].type) {
            case 'mqtt':
                return (<MqttConfig index={index} />);
            case 'kafka':
                return (<KafkaConfig index={index} />);
            case 'http-post':
                return (<HttpPostConfig index={index} />);
            case 'kinesis':
                return (<KinesisConfig index={index} />);
            case 'nats':
                return (<NatsConfig index={index} />);
            case 'tranquility':
                return (<TranquilityConfig index={index} />);
            case 'file':
                return (<FileConfig index={index} />);
            case 'iothub':
                return (<AzureConfig index={index} />);
            case 'logger':
                return (<LoggerConfig index={index} />);
            case "wamp":
                return (<WampConfig index={index} />)
            default: return '';
        }
    };

    const handleAddFields = () => {
        const values = [...stato];
        values.push({ type: '' });
        dispatch(addProducer(values));
        setNProd(nProd + 1);
    };

    const handleRemoveFields = index => {
        const values = [...stato];
        values.splice(index, 1);
        dispatch(addProducer(values));
        setNProd(nProd - 1);
    };
    const [open, setOpen] = React.useState(false);

    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }
    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };
    const formRef = React.useRef();
    return (
        <div ref={formRef}>
            <h5>Producers</h5>
            {stato.map((inputField, index) => (
                <div key={index} className='Campo'>
                    <FormControl className="SelectForm" variant='outlined' required>
                        <InputLabel>Producer</InputLabel>
                        <Select name='type'
                            label='Producer' defaultValue=''
                            value={stato.type}
                            onChange={event => handleInputChange(index, event)} >
                            <MenuItem value="logger">Logger</MenuItem>
                            <MenuItem value="file">File</MenuItem>
                            <MenuItem value="http-post">HTTP Post</MenuItem>
                            <MenuItem value="kafka">Kafka</MenuItem>
                            <MenuItem value="kinesis">Kinesis</MenuItem>
                            <MenuItem value="nats">NATS</MenuItem>
                            <MenuItem value="tranquility">Tranquility</MenuItem>
                            <MenuItem value="mqtt">Mqtt</MenuItem>
                            <MenuItem value="iothub">Azure IoT Hub</MenuItem>
                            <MenuItem value="wamp">Wamp</MenuItem>
                        </Select>
                    </FormControl>
                    <IconButton color="primary" aria-label="add to shopping cart" className="ButtonForm"
                        onClick={() => handleAddFields(index)}>
                        <BiPlusCircle />
                    </IconButton>
                    <IconButton color="secondary" aria-label="add an alarm" className="ButtonForm"
                        onClick={() => nProd !== 1 ? handleRemoveFields(index) : setOpen(true)}>
                        <BiMinusCircle />
                    </IconButton>
                    {selectType(index)}
                    <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                        <Alert onClose={handleClose} severity="warning">
                            Ci deve essere almeno un producer
                          </Alert>
                    </Snackbar>
                </div>
            ))}
        </div>
    )
}
export default DynamicSelect;