import React from 'react'
import '../App.css';
import { AccordionSummary, Accordion, AccordionDetails, Typography } from '@material-ui/core';
import { AiFillCaretDown, AiFillWarning } from 'react-icons/ai';
import { VscNewFile } from 'react-icons/vsc';
import { BsFillCaretRightFill } from 'react-icons/bs';

const Helper = () => {

    const [expanded, setExpanded] = React.useState(false);

    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(isExpanded ? panel : false);
    };

    return (
        <div className='Help'>
            <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>Come creare una simulazione</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Per poter creare una nuova simulazione, basta cliccare sul pulsante new <VscNewFile />.<br></br>
                       Compila i campi relativi al nome della simulazione, nome del workflow e nome del producer.
                       Puoi aggiungere un numero arbitrario di Workflows e Producers, cliccando sui pulsanti + e - .
                       Cliccando su Next potete definire le informazioni relative ai workflow e steps. Una volta completato tutto, cliccate su Finish.
                       A sinistra nella LeftBar potrai visualizzare la simulazione creata.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>Come avviare una simulazione</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Per avviare la simulazione clicca sul pulsante Run in alto <BsFillCaretRightFill />.<br></br>
                        Seleziona la simulazione che vuoi eseguire e clicca sul pusante run a destra. <br></br><br></br>
                        <AiFillWarning></AiFillWarning> &nbsp; E' possibile eseguire solo simulazioni che sono state create oppure importate tramite il pulsante open.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>E' possibile stoppare una simulazione in esecuzione</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Per poter stoppare una simulazione già esistente, basta cliccare sul pulsante Stop. <br>
                        </br>E' possibile rieseguire la stessa simulazione in qualsiasi momento, ricliccando sul pulsante Run.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>E' possibile salvare una simulazione creata</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        E' possibile salvare una simulazione cliccando sul pulsante Export.<br></br>
                        Verranno salvati almeno due file JSON: uno per relativo alla simulazione e tutti gli altri file relativi alla configurazione dei workflow.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>Come aprire una simulazione già esistente</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Per poter aprire una simulazione già esistente, basta cliccare sul pulsante Open e selezionare i file opportuni.<br></br><br></br>
                        <AiFillWarning></AiFillWarning> Inserire prima il file relativo alla simulazione e poi i file relativi ai workflows.
                        I file da importare devono essere in formato JSON.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel6'} onChange={handleChange('panel6')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>come modificare una simulazione</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Si è possibile modificare la simulazione in due modi: <br></br>
                        <br></br><b>1)</b> Se avete già una simulazione esistente, aprendola dal bottone Open, potete visualizzare la vostra simulazione
                        tramite un file editor json con il quale poter anche andare ad apportare modifiche. <br></br>
                        <br></br><b>2)</b>Se la simulazione è stata creata adesso da voi, nella leftbar vicino a ogni Porducer o Workflow creato, cliccando
                        sulla matita, potete andare a modificare i campi della vostra simulazione.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel7'} onChange={handleChange('panel7')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>Come eliminare una simulazione</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Per poter eliminare una simulazione, basta cliccare sulla simulazione nella barra laterale e cliccare sul pulsante Delete.
                    </Typography>
                </AccordionDetails>
            </Accordion>
            <Accordion expanded={expanded === 'panel8'} onChange={handleChange('panel8')}>
                <AccordionSummary expandIcon={<AiFillCaretDown />}>
                    <Typography>Quali tipi di producer si possono inserire</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <Typography className="Typography">
                        Si possono inserire diversi tipi di producer, ciascuno dei quali con diversi campi: <ul>
                            <li> <b>mqtt:</b> broker.server, broker.port, topic, clientId, qos,username, password</li>
                            <li> <b>http:</b> url</li>
                            <li> <b>kafka:</b> broker.server, broker.port, topic, flatten, sync</li>
                            <li> <b>kinesis:</b> stream, region, max.records, roleARN</li>
                            <li> <b>tranquility:</b> zookeeper.host, zookeeper.port, overlord.name, firehose.pattern, discovery.path, datasource.name,
                        timestamp.name, sync, geo.dimensions</li>
                            <li> <b>nats:</b> broker.server, broker.port, topic, flatten</li>
                            <li> <b>logger</b></li>
                            <li> <b>file:</b> output.directory, file.prefix, file.extension</li>
                            <li> <b>iothub:</b> connectionString, protocol</li>
                            <br></br><br>
                            </br></ul>
                        <AiFillWarning></AiFillWarning> Inserendo un tipo di producer diverso da quelli elencati, la simulazione non funzionerà.
                    </Typography>
                </AccordionDetails>
            </Accordion>
        </div>
    )
}
export default Helper;
