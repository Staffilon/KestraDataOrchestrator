import React from "react";
import '../App.css';
import { BiMinusCircle, BiPlusCircle, } from 'react-icons/bi';
import TextField from '@material-ui/core/TextField';
import IconButton from '@material-ui/core/IconButton'
import { useSelector, useDispatch } from "react-redux";
import { addWorkflowName } from '../actions/workflowName-action';
import { Snackbar } from "@material-ui/core";
import MuiAlert from '@material-ui/lab/Alert';

const DynamicFields = () => {

    const [nWF, setNWF] = React.useState(1);

    const stato = useSelector(state => state.wfname.data)
    const dispatch = useDispatch();

    const handleInputChange = (index, event) => {
        const values = [...stato];
        values[index].workflowName = event.target.value;
        values[index].workflowFilename = event.target.value + '.json';
        dispatch(addWorkflowName(values));
    };

    const handleAddFields = () => {
        const values = [...stato];
        values.push({ workflowName: '', workflowFilename: '.json' });
        dispatch(addWorkflowName(values));
        setNWF(nWF + 1);
    };

    const handleRemoveFields = index => {
        const values = [...stato];
        values.splice(index, 1);
        dispatch(addWorkflowName(values));
        setNWF(nWF - 1);
    };
    const [open, setOpen] = React.useState(false);

    function Alert(props) {
        return <MuiAlert elevation={6} variant="filled" {...props} />;
    }
    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };
    const formRef = React.useRef();
    return (
        <div ref={formRef}>
            <h5>Workflows</h5>
            {stato.map((inputField, index) => (
                <div key={index} className='Campo'>
                    <TextField className='DynamicForm' id="outlined-basic"
                        label="Workflow name" variant="outlined" value={stato.workflowName}
                        onChange={event => handleInputChange(index, event)} required />
                    <IconButton color="primary" aria-label="add to shopping cart" className="ButtonForm"
                        onClick={() => handleAddFields(index)}>
                        <BiPlusCircle />
                    </IconButton>
                    <IconButton color="secondary" aria-label="add an alarm" className="ButtonForm"
                        onClick={() => nWF !== 1 ? handleRemoveFields(index) : setOpen(true)}>
                        <BiMinusCircle />
                    </IconButton>
                    <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                        <Alert onClose={handleClose} severity="warning">
                            Ci deve essere almeno un workflow
                          </Alert>
                    </Snackbar>

                </div>
            ))}
        </div>
    )
}
export default DynamicFields;