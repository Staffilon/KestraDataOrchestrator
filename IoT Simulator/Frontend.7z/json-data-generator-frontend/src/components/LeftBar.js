import React from 'react'
import '../App.css';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import { AiFillPlusCircle, AiFillCaretDown, AiFillCaretUp } from 'react-icons/ai'
import { HiPencil } from 'react-icons/hi'
import { FaFileAlt } from 'react-icons/fa'
import { GrProductHunt } from 'react-icons/gr'
import { Link } from 'react-router-dom';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from '@material-ui/core';
import { addGlobalSimulation } from '../actions/globalSimulation-action';
import axios from 'axios';

const LeftBar = () => {

    const [openW, setOpenW] = React.useState(true);

    const handleClickW = () => {
        setOpenW(!openW);
    };
    const dispatch = useDispatch();
    const [openP, setOpenP] = React.useState(true);

    const handleClickP = () => {
        setOpenP(!openP);
    };

    const globalSimu = useSelector(state => state.globalSimu.data)

    const [expanded, setExpanded] = React.useState(false);

    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(isExpanded ? panel : false);
    };

    const deleteFile = (file) => {
        axios.delete(`http://localhost:8080/delete/${file}`);
    };

    const deleteSim = (index) => {
        globalSimu[index].roba.workflows.map(wf => {
            deleteFile(wf.workflowFilename)
        })
        deleteFile(globalSimu[index].simName + '.json')
        let data = [...globalSimu];
        data.splice(index, 1)
        dispatch(addGlobalSimulation(data))
    }

    return (
        <div className='LeftBar'>
            {globalSimu.map((simu, indiceSimu) => (
                simu.simName === '' ? <div /> :
                    <Accordion key={indiceSimu} expanded={expanded === simu.simName} onChange={handleChange(simu.simName)}>
                        <AccordionSummary expandIcon={<AiFillPlusCircle color="#0070ba" />}>
                            <p style={{ fontSize: 25 }}>{simu.simName}</p>
                        </AccordionSummary>
                        <AccordionDetails>
                            <div className="Typography">
                                <List>
                                    <ListItem button onClick={handleClickP}>
                                        <ListItemIcon>
                                            <GrProductHunt color="#0070ba" />
                                        </ListItemIcon>
                                        <ListItemText primary="Producers" />
                                        {openP ? <AiFillCaretDown /> : <AiFillCaretUp />}
                                    </ListItem>
                                    <Collapse in={openP} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            {simu.roba.producers.length === 0 ? <div /> :
                                                simu.roba.producers.map((producer, index) => (
                                                    <div key={index}><ListItem button  >
                                                        <ListItemText primary={producer.type} />
                                                        <Link to={`/modifyProducer/${indiceSimu}/${index}`} style={{ color: "black" }}>
                                                            <HiPencil></HiPencil></Link>
                                                    </ListItem></div>
                                                ))}
                                        </List>
                                    </Collapse>

                                    <ListItem button onClick={handleClickW}>
                                        <ListItemIcon>
                                            <FaFileAlt color="#0070ba" />
                                        </ListItemIcon>
                                        <ListItemText primary="Workflows" />
                                        {openP ? <AiFillCaretDown /> : <AiFillCaretUp />}
                                    </ListItem>
                                    <Collapse in={openW} timeout="auto" unmountOnExit>
                                        <List component="div" disablePadding>
                                            {simu.roba.workflows.map((workflow, index) => (
                                                <div key={index}>
                                                    <ListItem button>
                                                        <ListItemText primary={workflow.workflowName} />
                                                        <Link to={`/modifyWorkflow/${indiceSimu}/${index}`} style={{ color: "black" }}>
                                                            <HiPencil></HiPencil></Link>
                                                    </ListItem></div>
                                            ))}
                                        </List>
                                    </Collapse>
                                </List>
                            </div>
                        </AccordionDetails>
                        <div className="DeleteButton">
                            <Button variant="contained" color="secondary" onClick={() => deleteSim(indiceSimu)}>Delete</Button>
                        </div>
                    </Accordion>)
            )}
        </div>)
}

export default LeftBar;