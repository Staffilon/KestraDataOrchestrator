import { SIMULATION } from "../constants/action-types";

const initialState =
{
    data:
    {
        simName: '',
        roba: {
            producers: [{

            }],
            workflows: [{

            }]
        },
        w: []

    }

}

const simulationReducer = (state = initialState, action) => {
    switch (action.type) {
        case SIMULATION:
            return {
                ...state,
                data: action.payload,
            };

        default:
            return state;
    }
};
export default simulationReducer;