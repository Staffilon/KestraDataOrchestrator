import { GLOBAL_SIMULATION } from "../constants/action-types";

const initialState =
{
    data: [

    ]
}

const globalSimulationReducer = (state = initialState, action) => {
    switch (action.type) {
        case GLOBAL_SIMULATION:
            return {
                ...state,
                data: action.payload,
            };

        default:
            return state;
    }
};
export default globalSimulationReducer;