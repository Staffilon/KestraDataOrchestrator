import { combineReducers } from 'redux';
import workflowName from '../reducers/workflow-name'
import producerReducer from './producer-reducer';
import simulationReducer from './Simulation-reducer'
import workflowConfig from './workflowConfig-reducer';
import nStepReducer from './nStep-reducer'
import counterWf from './counterWf-reducer'
import globalSimulationReducer from './globalSimulation-reducer'
import isRunningReducer from './isRunning-reducer';

const root = combineReducers({
    wfname: workflowName,
    producer: producerReducer,
    simulation: simulationReducer,
    workflow: workflowConfig,
    nStep: nStepReducer,
    counterWf: counterWf,
    globalSimu: globalSimulationReducer,
    running: isRunningReducer,
})
export default root;