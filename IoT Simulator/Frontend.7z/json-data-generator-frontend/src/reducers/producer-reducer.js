import { TYPE_PRODUCER } from "../constants/action-types";

const initialState =
{
    data: [{
        type: '',
        s: {

        }
    }]
}

const producerReducer = (state = initialState, action) => {
    switch (action.type) {
        case TYPE_PRODUCER:
            return {
                ...state,
                data: action.payload,
            };

        default:
            return state;
    }
};
export default producerReducer;