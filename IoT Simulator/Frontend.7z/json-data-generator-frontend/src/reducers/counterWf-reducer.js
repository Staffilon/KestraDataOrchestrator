import { COUNTER_WF } from "../constants/action-types";

const initialState = 0;

const counterWf = (state = initialState, action) => {
    switch (action.type) {
        case COUNTER_WF:
            return action.payload

        default:
            return state;
    }
};
export default counterWf;