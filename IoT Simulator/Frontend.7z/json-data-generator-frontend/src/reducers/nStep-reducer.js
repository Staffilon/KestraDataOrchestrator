import { N_STEP } from "../constants/action-types";

const initialState =
{
    data: 1
}

const nStepReducer = (state = initialState, action) => {
    switch (action.type) {
        case N_STEP:
            return {
                ...state,
                data: action.payload
            };

        default:
            return state;
    }
};
export default nStepReducer;