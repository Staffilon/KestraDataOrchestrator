import { WORKFLOW_NAME } from "../constants/action-types";

const initialState =
{
    data: [{
        workflowName: '',
        workflowFilename: '.json'
    }]
}

const workflowName = (state = initialState, action) => {
    switch (action.type) {
        case WORKFLOW_NAME:
            return {
                ...state,
                data: action.payload
            };

        default:
            return state;
    }
};
export default workflowName;