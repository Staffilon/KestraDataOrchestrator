import { ISRUNNING } from "../constants/action-types";

const initialState = false;

const isRunningReducer = (state = initialState, action) => {
    switch (action.type) {
        case ISRUNNING:
            return !state

        default:
            return state;
    }
};
export default isRunningReducer;