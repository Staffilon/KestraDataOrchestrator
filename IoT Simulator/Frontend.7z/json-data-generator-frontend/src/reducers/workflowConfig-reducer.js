import { WORKFLOW_CONFIG } from "../constants/action-types";

const initialState =
{
    data: {
        eventFrequency: 0,
        varyEventFrequency: true,
        repeatWorkflow: false,
        iterations: -1,
        timeBetweenRepeat: 0,
        varyRepeatFrequency: false,
        stepRunMode: 'sequencial',
        steps: []
    }
}

const workflowConfig = (state = initialState, action) => {
    switch (action.type) {
        case WORKFLOW_CONFIG:
            return {
                ...state,
                data: action.payload
            };

        default:
            return state;
    }
};
export default workflowConfig;