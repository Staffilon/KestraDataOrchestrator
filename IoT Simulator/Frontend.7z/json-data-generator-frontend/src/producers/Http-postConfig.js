import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';
const HttpPostConfig = (props) => {

    const [state, setState] = React.useState({
        type: 'http',
        url: "http://localhost:8050/ingest",
    });

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'http-post';
        values[props.index].s = state;
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])
    const formRef = React.useRef();
    return (
        <div className="FormProducer" ref={formRef}>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Url" variant="outlined" value={state.url}
                    onChange={handleChange2} name='url' required />
            </div>
        </div>
    )
}
export default HttpPostConfig;