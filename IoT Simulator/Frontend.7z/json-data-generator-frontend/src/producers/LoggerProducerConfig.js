import React, { useEffect } from 'react'
import '../App.css';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';

const LoggerConfig = (props) => {
    const formRef = React.useRef();

    const [state, setState] = React.useState({
        type: "logger",
    });

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'logger';
        values[props.index].s = state;
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])

    return (
        <div className="FormProducer" ref={formRef}>

        </div>
    )
}
export default LoggerConfig;