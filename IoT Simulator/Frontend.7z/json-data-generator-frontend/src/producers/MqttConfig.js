import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';


const MqttConfig = (props) => {

    const [state, setState] = React.useState({
        type: 'mqtt',
        brokerServer: 'tcp://localhost',
        brokerPort: 1883,
        topic: '/logevent',
        clientId: "LogEvent",
        qos: 2,
        username: '',
        password: '',
    });

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value })
    };

    const handleChange3 = (event) => {
        setState({ ...state, [event.target.name]: parseInt(event.target.value, 10) })
    };
    const parseStringa = () => {
        let data = {
            "type": state.type,
            "broker.server": state.brokerServer,
            "broker.port": state.brokerPort,
            "topic": state.topic,
            "clientId": state.clientId,
            "qos": state.qos,
            "username": state.username,
            "password": state.password,
        }
        return data;
    }

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'mqtt';
        values[props.index].s = parseStringa();
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])

    const formRef = React.useRef();

    return (
        <div>
            <div className='Field' ref={formRef}>
                <TextField className='Input' id="outlined-basic"
                    label="Broker server" variant="outlined" value={state.brokerServer}
                    onChange={handleChange2} name='brokerServer' required />
            </div>
            <div className='Field'>
                <TextField className='Input' id="filled-number" label="Broker port" type="number" InputProps={{ inputProps: { min: 1 } }} variant='outlined'
                    value={state.brokerPort} onChange={handleChange3} name='brokerPort' required />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.topic} variant='outlined' label='Topic'
                    onChange={handleChange2} name='topic' required />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.clientId} variant='outlined' label='Client ID'
                    onChange={handleChange2} name='clientId' required />
            </div>
            <div className='Field'>
                <TextField className='Input' variant='outlined' id="filled-number" label="QoS" type="number" InputProps={{ inputProps: { min: 1 } }}
                    value={state.qos} onChange={handleChange3} name='qos' required />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.username} variant='outlined' label='Username'
                    onChange={handleChange2} name='username' />
            </div>
            <div className='Field'>
                <TextField className='Input' id="standard-password-input" label="Password" value={state.password}
                    variant='outlined' onChange={handleChange2} name='password'
                />
            </div>
        </div>
    )
}
export default MqttConfig;