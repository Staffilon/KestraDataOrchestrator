import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import { useSelector, useDispatch } from 'react-redux';

import { addProducer } from '../actions/producer-action';

const FileConfig = (props) => {

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const [state, setState] = React.useState({
        type: "file",
        outputDirectory: "/tmp/dropbox/test2",
        filePrefix: "MYPREFIX_",
        fileExtension: ".json"
    });

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const parseStringa = () => {
        let data= {"type": state.type,
        "output.directory": state.outputDirectory,
        "file.prefix": state.filePrefix,
        "file.extension": state.fileExtension
    }
    return data;}

    const formRef = React.useRef();
    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'file';
        values[props.index].s = parseStringa();
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])

    return (
        <div className="FormProducer" ref= {formRef}>
            <div className='Field'>
                <TextField className='Input' value={state.outputDirectory} variant='outlined' label='Output directory'
                    onChange={handleChange2} name='outputDirectory' required />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.filePrefix} variant='outlined' label='File Prefix'
                    onChange={handleChange2} name='filePrefix' required/>
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.fileExtension} variant='outlined' label='File Extension'
                    onChange={handleChange2} name='fileExtension' required/>
            </div>
        </div>
    )
}
export default FileConfig;