import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import { FormControl } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';

const AzureConfig = (props) => {
    const formRef = React.useRef();
    const [state, setState] = React.useState({
        type: "iothub",
        connectionString: "<- Get from Azure portal or Device Explorer ->",
        protocol: "https",
    });

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'iothub';
        values[props.index].s = state;
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])

    return (
        <div className="FormProducer" ref= {formRef}>
            <div className='Field'>
                <TextField className='Input' value={state.connectionString} variant='outlined' label='Connection string'
                    onChange={handleChange2} name='connectionString' required/>
            </div>
            <div className='Field'>
                <FormControl className="Input" variant='outlined' required>
                    <InputLabel>Protocol</InputLabel>
                    <Select
                        label='Protocol'
                        value={state.protocol}
                        onChange={handleChange2} name='protocol'>
                        <MenuItem value="https">HTTPS</MenuItem>
                        <MenuItem value="mqtt">MQTT</MenuItem>
                        <MenuItem value="amqps">AMQPS</MenuItem>
                    </Select>
                </FormControl>
            </div>
        </div>
    )
}
export default AzureConfig;