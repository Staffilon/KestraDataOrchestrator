import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';
const KinesisConfig = (props) => {

    const [state, setState] = React.useState({
        type: "kinesis",
        stream: "data-input-stream",
        region: "ap-southeast-2",
        maxRecords: 1000,
        roleARN: "arn:aws:iam::XXXXXX2342:role/Kinesis-Access-Role"
    });

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const handleChange3 = (event) => {
        setState({ ...state, [event.target.name]: parseInt(event.target.value, 10) })
    };
    const parseStringa = () => {
        let data = {
            "type": state.type,
            "stream": state.stream,
            "region": state.region,
            "max.records": state.maxRecords,
            "roleARN": state.roleARN
        }
        return data;
    }

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'kinesis';
        values[props.index].s = parseStringa();
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])
    const formRef = React.useRef();
    return (
        <div className="FormProducer" ref={formRef}>
            <div className='Field'>
                <TextField className='Input' value={state.stream} variant='outlined' label='Stream'
                    onChange={handleChange2} name='stream' required />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.region} variant='outlined' label='Region'
                    onChange={handleChange2} name='region' required />
            </div>
            <div className='Field'>
                <TextField className='Input' label="Max records" type="number" variant='outlined'
                    value={state.maxRecords} onChange={handleChange3} name='maxRecords' required />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.roleARN} variant='outlined' label='Role ARN'
                    onChange={handleChange2} name='roleARN' required />
            </div>
        </div>
    )
}
export default KinesisConfig;