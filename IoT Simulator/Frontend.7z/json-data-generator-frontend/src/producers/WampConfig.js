import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';
const WampConfig = (props) => {

    const [state, setState] = React.useState({
        type: 'wamp',
        url: "wss://www.connectanum.com/wamp",
        realm: "test.unicam.it",
        topic: "/test.unicam.it/test"
    });

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'wamp';
        values[props.index].s = state;
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])
    const formRef = React.useRef();
    return (
        <div className="FormProducer" ref={formRef}>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Url" variant="outlined" value={state.url}
                    onChange={handleChange2} name='url' required />
            </div>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Realm" variant="outlined" value={state.realm}
                    onChange={handleChange2} name='realm' required />
            </div>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Topic" variant="outlined" value={state.topic}
                    onChange={handleChange2} name='topic' required />
            </div>
        </div>
    )
}
export default WampConfig;