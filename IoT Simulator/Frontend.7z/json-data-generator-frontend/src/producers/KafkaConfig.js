import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';


const KafkaConfig = (props) => {

    const [state, setState] = React.useState({
        type: 'kafka',
        brokerServer: '192.168.59.103',
        brokerPort: 9092,
        topic: '/logevent',
        flatten: false,
        sync: false,
    });
    const formRef = React.useRef();
    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked })
    };

    const handleChange3 = (event) => {
        setState({ ...state, [event.target.name]: parseInt(event.target.value, 10) })
    };
    const parseStringa = () => {
        let data = {
            "type": state.type,
            "broker.server": state.brokerServer,
            "broker.port": state.brokerPort,
            "topic": state.topic,
            "flatten": state.flatten,
            "sync": state.sync
        }
        return data;
    }


    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'kafka';
        values[props.index].s = parseStringa();
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])

    return (
        <div className="FormProducer" ref={formRef}>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Broker server" variant="outlined" value={state.brokerServer}
                    onChange={handleChange2} name='brokerServer' required />
            </div>
            <div className='Field'>
                <TextField className='Input' required id="standard-number" label="Broker port" type="number" InputProps={{ inputProps: { min: 1 } }} variant='outlined'
                    value={state.brokerPort} onChange={handleChange3} name='brokerPort' />
            </div>
            <div className='Field'>
                <TextField className='Input' required value={state.topic} variant='outlined' label='Topic'
                    onChange={handleChange2} name='topic' />
            </div>
            <div className='Field'>
                <FormControlLabel
                    value="start"
                    control={<Switch checked={state.flatten} onChange={handleChange} name="flatten" />}
                    label="Flatten"
                    labelPlacement="start"
                />
            </div>
            <div className='Field'>
                <FormControlLabel
                    value="start"
                    control={<Switch checked={state.sync} onChange={handleChange} name="sync" />}
                    label="Sync"
                    labelPlacement="start"
                />
            </div>
        </div>
    )
}
export default KafkaConfig;