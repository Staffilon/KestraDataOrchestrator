import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';
const TranquilityConfig = (props) => {

    const [state, setState] = React.useState({
        type: 'tranquility',
        zookeeperHost: "localhost",
        zookeeperPort: 2181,
        overlordName: 'overlord',
        firehosePattern: "druid:firehose:%s",
        discoveryPath: "/druid/discovery",
        datasourceName: "test",
        timestampName: "startTime",
        sync: true,
        geoDimensions: "where.latitude,where.longitude",
    });

    const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
    };

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const handleChange3 = (event) => {
        setState({ ...state, [event.target.name]: parseInt(event.target.value, 10) })
    };

    const parseStringa = () => {
        let data = {
            "type": state.type,
            "zookeeper.host": state.zookeeperHost,
            "zookeeper.port": state.zookeeperPort,
            "overlord.name": state.overlordName,
            "firehose.pattern": state.firehosePattern,
            "discovery.path": state.discoveryPath,
            "datasource.name": state.datasourceName,
            "timestamp.name": state.timestampName,
            "sync": true,
            "geo.dimensions": state.geoDimensions,
        }
        return data;
    }

    useEffect(() => {
        const ciao = () => {
            const values = [...stato];
            values[props.index].type = 'tranquility';
            values[props.index].s = parseStringa();
            dispatch(addProducer(values))
        }
        ciao();
    }, [state]);
    const formRef = React.useRef();
    return (
        <div className="FormProducer" ref={formRef}>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Zookeper Host" variant="outlined" value={state.zookeeperHost}
                    onChange={handleChange2} name='zookeeperHost' required />
            </div>
            <div className='Field'>
                <TextField className='Input' id="standard-number" required label="Zookeper port" type="number" InputProps={{ inputProps: { min: 1 } }}
                    variant='outlined' value={state.zookeeperPort} onChange={handleChange3} name='zookeeperPort' />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.overlordName} required variant='outlined' label='Overlord Name'
                    onChange={handleChange2} name='overlordName' />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.firehosePattern} required variant='outlined' label='Firehose Pattern'
                    onChange={handleChange2} name='firehosePattern' />
            </div>
            <div className='Field'>
                <TextField className='Input' variant='outlined' required label="Discovery path" value={state.discoveryPath}
                    onChange={handleChange2} name='discoveryPath' />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.datasourceName} required variant='outlined' label='Datascource name'
                    onChange={handleChange2} name='datasourceName' />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.timestampName} required variant='outlined' label='Timestamp name'
                    onChange={handleChange2} name='timestampName' />
            </div>
            <div className='Field'>
                <FormControlLabel
                    value="start"
                    control={<Switch checked={state.sync} onChange={handleChange} name="sync" />}
                    label="Sync"
                    labelPlacement="start" />
            </div>
            <div className='Field'>
                <TextField className='Input' value={state.geoDimensions} required variant='outlined' label='Geo Dimensions'
                    onChange={handleChange2} name='geoDimensions' />
            </div>
        </div>
    )
}
export default TranquilityConfig;