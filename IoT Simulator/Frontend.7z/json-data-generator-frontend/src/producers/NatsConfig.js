import React, { useEffect } from 'react'
import '../App.css';
import TextField from '@material-ui/core/TextField';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { useSelector, useDispatch } from 'react-redux';
import { addProducer } from '../actions/producer-action';
const NatsConfig = (props) => {

    const [state, setState] = React.useState({
        type: 'nats',
        server: "127.0.0.1",
        port: 4222,
        topic: '/logevent',
        flatten: false,
    });

    const handleChange = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
    };

    const handleChange2 = (event) => {
        setState({ ...state, [event.target.name]: event.target.value });
    };

    const stato = useSelector(state => state.producer.data)
    const dispatch = useDispatch();

    const handleChange3 = (event) => {
        setState({ ...state, [event.target.name]: parseInt(event.target.value, 10) })
    };
    const parseStringa = () => {
        let data= {"type": state.type,
        "broker.server": state.server,
        "broker.port": state.port,
        "topic": state.topic,
        "flatten": state.flatten,
    }
    return data;}


    const ciao = () => {
        const values = [...stato];
        values[props.index].type = 'nats';
        values[props.index].s =parseStringa();
        dispatch(addProducer(values))
    }
    useEffect(() => { ciao() }, [state])
    const formRef = React.useRef();
    return (
        <div className="FormProducer" ref={formRef}>
            <div className='Field'>
                <TextField className='Input' id="outlined-basic"
                    label="Broker server" variant="outlined" value={state.server}
                    onChange={handleChange2} name='server' required />
            </div>
            <div className='Field'>
                <TextField className='Input' required id="standard-number" label="Broker port" type="number"  InputProps={{ inputProps: { min: 1 } }} variant='outlined'
                    value={state.port} onChange={handleChange3} name='port'  />
            </div>
            <div className='Field'>
                <TextField className='Input' required value={state.topic} variant='outlined' label='Topic'
                    onChange={handleChange2} name='topic' />
            </div>
            <div className='Field'>
                <FormControlLabel
                    value="start"
                    control={<Switch checked={state.flatten} onChange={handleChange} name="flatten" />}
                    label="Flatten"
                    labelPlacement="start"
                />
            </div>
        </div>
    )
}
export default NatsConfig;