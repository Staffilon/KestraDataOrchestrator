import { createStore } from 'redux';
import root from '../reducers/root-reducer'
import { loadState, saveState } from './persistedState';

const persistedState = loadState();

const store = createStore(
    root,
    persistedState
);

store.subscribe(() => {
    saveState(store.getState())
})

export default store;